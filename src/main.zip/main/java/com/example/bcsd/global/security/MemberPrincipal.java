package com.example.bcsd.global.security;

public record MemberPrincipal(
        Long memberId,
        String email
) {
}
