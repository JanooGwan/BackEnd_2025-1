package com.example.bcsd.controller.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record BoardUpdateRequest(

        @NotBlank(message = "게시판 이름은 필수입니다.")
        @Size(min = 1, max = 20, message = "게시판 이름은 1~20자 사이여야 합니다.")
        String name
) {
}
