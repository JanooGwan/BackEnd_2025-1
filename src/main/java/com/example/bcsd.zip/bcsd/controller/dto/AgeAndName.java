package com.example.bcsd.controller.dto;

public record AgeAndName(
        int age,
        String name
) {}
